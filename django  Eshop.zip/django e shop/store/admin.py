from django.contrib import admin
from .mode.product import Product
from .mode.category import Category
from store.mode.section import Section
from .mode.customer import Customer
from .mode.order import Order

class AdminProduct(admin.ModelAdmin):
    list_display =['name','price','category']

class AdminCategory(admin.ModelAdmin):
    list_display =['name']




# Register your models here.
admin.site.register(Product,AdminProduct)
admin.site.register(Category,AdminCategory)
admin.site.register(Section)
admin.site.register(Customer)
admin.site.register(Order)


