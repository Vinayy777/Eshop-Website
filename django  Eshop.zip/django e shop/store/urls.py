from .views import index,signup,login,cart,check_out,order
from django.urls import path
from .middlewares.auth import simple_middleware

urlpatterns=[
    path('',index.Index.as_view(), name='homepage'),
    path('signup',signup.Signup.as_view(), name='signup'),
    path('login',login.Login.as_view(), name='login'),
    path('logout',login.logout, name='logout'),
    path('cart',cart.Cart.as_view(), name='cart'),
    path('check_out',check_out.Check_out.as_view(), name='check_out'),
    path('orders',simple_middleware(order.OrderView.as_view()) ,name='orders'),
]
