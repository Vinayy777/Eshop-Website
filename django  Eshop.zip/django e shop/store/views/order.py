from django.shortcuts import render,redirect
from django.views import View
 
from store.mode.order import Order
from store.middlewares.auth import simple_middleware
from django.utils.decorators import method_decorator 
class OrderView(View):
 
     @method_decorator(simple_middleware)
     def get(self,request):
         customer=request.session.get('customer')
         order=Order.get_orders_by_customer(customer)
         print(order)
         return render(request,'order.html',{'orders':order})

