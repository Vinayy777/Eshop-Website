from django.shortcuts import render,redirect
from django.views import View
from store.mode.product import Product
from store.mode.order import Order
from store.mode.customer import Customer

class Check_out(View):
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customerr=request.session.get('customer')
        cart=request.session.get('cart')
        products=Product.get_products_by_id(list(cart.keys()))
        print(address,phone,customerr,cart,products)
        
        for product  in products:
            print(customerr)
            order=Order(customer=Customer(id=customerr),
                        product=product,
                        price=product.price,
                        address=address,
                        phone=phone,
                        quantity=cart.get(str(product.id)))     
            order.place_orders()
            
        request.session['cart']={}


        return redirect('cart')
