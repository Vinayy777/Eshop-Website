from django.shortcuts import render,redirect
 
from store.mode.customer import Customer
from django.contrib.auth.hashers import make_password 
from django.views import View



class Signup(View):
    def get(self,request):
         return render(request,'signup.html')
    
    def post(self,request):
        postdata=request.POST
        first_nm=postdata.get('firstname')
        last_nm=postdata.get('lastname')
        phone=postdata.get('phoneno')
        email=postdata.get('email')
        password=postdata.get('password')
      
        # validation
        value={
            'first_name':first_nm,
            'last_name':last_nm,
            'phone':phone,
            'email':email
        }    

        error_msg=None
        customer=Customer(first_name=first_nm,
                          last_name=last_nm,
                          phone=phone,
                          email=email,
                          password=password)
        error_msg=self.validateCustomer(first_nm,last_nm,phone,password,customer)
 
        # saving
        if not error_msg:
           print(first_nm,last_nm,email,phone,password)
           customer.password=make_password(customer.password) 
           customer.register()
           return redirect('homepage')
        else :  
            data = {
              'error':error_msg,
               'values':value
          }
            return render(request,'signup.html',data)
        
    def validateCustomer(self,first_nm,last_nm,phone,password,customer):
        error_msg=None;
        if(not first_nm):
            error_msg="First name required !!"
        elif len(first_nm) < 4 :
            error_msg ="first name must be atleast 4 character "    
        elif not last_nm:
            error_msg="Last name required !!"
        elif len(last_nm) < 4 :
            error_msg ="Last name must be atleast 4 character "    
        elif not phone :
            error_msg= "Phone Number required !!"
        elif len(phone) < 10 :
            error_msg =" Phone no must be in 10 digits  "    
        elif not password :
            error_msg= "Password required !!"
        elif customer.isExists():
            error_msg= 'Email address already registered !!'   

        return error_msg
